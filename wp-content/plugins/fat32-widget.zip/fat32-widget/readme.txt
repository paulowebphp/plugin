=== Fat32 Widget ===
Contributors: paulowebphp
Donate link: https://fat32.com.br/
Tags: social network
Requires at least: 1.0
Tested up to: 1.0
Requires PHP: 5.2.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Teste de publicação na loja Wordpress de Plugin desenvolvido para teste durante curso 'Desenvolvimento de Plugins para Wordpress - Crie 10 plugins", de Elton Oliveira.
 
== Description ==
 
Teste de publicação na loja Wordpress de Plugin desenvolvido para teste durante curso 'Desenvolvimento de Plugins para Wordpress - Crie 10 plugins", de Elton Oliveira.

Este plugin ativa um Widget onde o usuário pode inserir os links dos perfis do Facebook, Twitter, Instagram e Youtube.

== Installation ==
 
Para instalar o plugin:
 
1. Faça o upload do plugin para o diretório `/wp-content/plugins/` 
2. Ative o plugin pelo menu 'Plugins' no WordPress
3. Em 'Temas', 'Personalizar', adicione o plugin em qualquer área desejada dentro do seu tema
4. Insria os links desejados e salve
 
== Frequently Asked Questions ==
 
Sem perguntas no momento.
 
== Screenshots ==
 
1. minhas_redes_sociais/assets/screenshot-1.png
 
== Changelog ==
 
= 1.0 =
* Primeira versaõ version (dev).
 

